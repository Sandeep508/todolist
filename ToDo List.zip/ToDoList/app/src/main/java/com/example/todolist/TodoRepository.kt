package com.example.todolist

import android.content.Context
import android.view.View
import androidx.lifecycle.LiveData

class TodoRepository(context: Context) {
    var db: ToDoDao? = AppDatabase.getInstance(context)?.todoDao()

    fun getAllTodos(): LiveData<List<Todo>>?{
        return db?.selectTodo()
    }
    fun search(name: String): LiveData<List<Todo>>? {
        return (db?.searchTodo("%" + name + "%")?: listOf<Todo>()) as LiveData<List<Todo>>?
    }
    fun insertTodo(todo: Todo){
        db?.insertTodo(todo)
    }
    fun updateTodo(todo: Todo) {
        db?.updateTodo(todo)
    }
    fun deleteTodo(todo: Todo){
        db?.deleteTodo(todo)
    }

}