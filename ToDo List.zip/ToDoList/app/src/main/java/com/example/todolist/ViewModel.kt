package com.example.todolist

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class ViewModel(app: Application): AndroidViewModel(app) {
    private val repo: TodoRepository
    val allTodos : LiveData<List<Todo>>?

    init {
        repo = TodoRepository(app)
        allTodos = repo.getAllTodos()
    }

    fun getAllTodos()= viewModelScope.launch {
        repo.getAllTodos()
    }
        fun search(searchText : String)= viewModelScope.launch{
        repo.search(searchText)
    }
    fun insertTodo(todo: Todo)= viewModelScope.launch{
        repo.insertTodo(todo)
    }
    fun updateTodo(todo: Todo)= viewModelScope.launch {
        repo.updateTodo(todo)
    }
    fun deleteTodo(todo: Todo)= viewModelScope.launch{
        repo.deleteTodo(todo)
    }
}