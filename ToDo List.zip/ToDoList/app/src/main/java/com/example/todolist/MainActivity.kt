package com.example.todolist

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.todolist.UI.Loading
import com.google.android.material.floatingactionbutton.FloatingActionButton



class MainActivity : AppCompatActivity() {

    var backPressedTime: Long = 0
    var TodoList = ArrayList<Todo>()
    lateinit var vm : ViewModel
    lateinit var adapter: TodoAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val loading = Loading(this)
        loading.startLoading()
        val handler = Handler()
        handler.postDelayed(object : Runnable{
            override fun run() {
                loading.isDismiss()
            }
        }, 2000)

        vm = ViewModel(application)


        vm.allTodos?.observe(this, {
                TodoList -> getTodo(TodoList)
        })


        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)

        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = TodoAdapter({position -> onCardClick(position) }, TodoList)

        recyclerView.adapter = adapter


        var floating: FloatingActionButton = findViewById(R.id.svbutton)
        floating.setOnClickListener{
            val myIntent = Intent(this, MainActivity2::class.java)
            startActivity(myIntent)
        }

        var delete: View? = findViewById(R.id.delete)
        if (delete != null) {
            delete.setOnClickListener{
                val myIntent = Intent(this, MainActivity3::class.java)
                startActivity(myIntent)
            }
        }

    }


    fun onCardClick(position: Int){
        println("position:$position")
        val myIntent = Intent(this, MainActivity3::class.java)
        myIntent.putExtra("Id", TodoList[position].todoId)
        myIntent.putExtra("Name", TodoList[position].Name)
        myIntent.putExtra("Description", TodoList[position].Description)
        startActivity(myIntent)
    }
    fun getTodo(studentList: List<Todo>){
        this.TodoList.clear()
        this.TodoList.addAll(studentList)
        adapter.notifyDataSetChanged()
    }
    override fun onBackPressed(){
        if(backPressedTime + 3000 > System.currentTimeMillis()){
            super.onBackPressed()
            finish()
        }else {
            Toast.makeText(this, "Press back again to exit", Toast.LENGTH_LONG).show()
        }
        backPressedTime = System.currentTimeMillis()
    }



}