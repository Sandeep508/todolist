package com.example.todolist

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity2 : AppCompatActivity() {

    lateinit var vm : ViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        var actionBar = getSupportActionBar()
        if (actionBar != null){
            actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_arrow_back_24)
            actionBar.setDisplayHomeAsUpEnabled(true)
        }

        vm = ViewModel(application)

        var name: EditText = findViewById(R.id.name)
        var desc: EditText = findViewById(R.id.desc)
        var save: Button = findViewById(R.id.save)
        var clear: Button = findViewById(R.id.clear)

        save.setOnClickListener {
            vm.insertTodo(Todo(null, name.text.toString(), desc.text.toString()))
            val myIntent = Intent(this, MainActivity::class.java)
            startActivity(myIntent)
            Toast.makeText(this, "List Added Successfully" , Toast.LENGTH_LONG).show()
        }


    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

}