package com.example.todolist

import androidx.lifecycle.LiveData
import androidx.room.*
import org.w3c.dom.Text

@Dao
interface ToDoDao{
    @Insert
    fun insertTodo(todo: Todo)

    @Query("select * from Todo")
    fun selectTodo(): LiveData<List<Todo>>

    @Query("select * from Todo where name like :name or description like :name")
    fun searchTodo(name: String):LiveData<List<Todo>>

    @Update
    fun updateTodo(todo: Todo)

    @Delete
    fun deleteTodo(todo: Todo)

}