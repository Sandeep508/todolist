package com.example.todolist


import android.app.AlertDialog
import android.content.Intent
import android.media.metrics.Event
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast


class MainActivity3 : AppCompatActivity() {

    lateinit var vm : ViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)


        var actionBar = getSupportActionBar()
        if (actionBar != null){
            actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_arrow_back_24)
            actionBar.setDisplayHomeAsUpEnabled(true)
        }

        vm = ViewModel(application)

        var id: TextView = findViewById(R.id.list)
        var name: EditText = findViewById(R.id.nameupdate)
        var desc: EditText = findViewById(R.id.descupdate)
        var update: Button = findViewById(R.id.update)
        var delete: Button = findViewById(R.id.delete)

        id.setText(intent.getIntExtra("Id", 0).toString())
        name.setText(intent.getStringExtra("Name"))
        desc.setText(intent.getStringExtra("Description"))

        update.setOnClickListener {
            vm.updateTodo(Todo(id.text.toString().toInt(), name.text.toString(), desc.text.toString()))
            val myIntent = Intent(this, MainActivity::class.java)
            startActivity(myIntent)
            Toast.makeText(this, "List Updated Successfully" , Toast.LENGTH_LONG).show()

        }
        delete.setOnClickListener {
            vm.deleteTodo(Todo(id.text.toString().toInt(), name.text.toString(), desc.text.toString()))
            val myIntent1 = Intent(this, MainActivity::class.java)
            startActivity(myIntent1)
            Toast.makeText(this, "List Deleted Successfully" , Toast.LENGTH_LONG).show()

        }


    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

}