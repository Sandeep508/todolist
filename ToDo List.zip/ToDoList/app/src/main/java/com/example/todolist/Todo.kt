package com.example.todolist

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "todo")
data class Todo (@PrimaryKey()var todoId:Int?,
                 @ColumnInfo(name = "name")var Name:String?,
                 @ColumnInfo(name = "description")var Description:String?
                 )
