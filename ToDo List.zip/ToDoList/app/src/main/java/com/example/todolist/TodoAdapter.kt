package com.example.todolist

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class TodoAdapter(private val onCardClick: (position: Int) -> Unit,
                  private var TodoList: List<Todo>) : RecyclerView.Adapter<ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.layout_todo_list, parent, false)

        return ViewHolder(view, onCardClick)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val itemVM = TodoList[position]
        holder.name.text = itemVM.Name
        holder.desc.text = itemVM.Description
    }
    override fun getItemCount(): Int {

        return TodoList.size
    }

}

class ViewHolder(view: View, private val onCardClick: (position: Int) -> Unit)
    :RecyclerView.ViewHolder(view), View.OnClickListener{
    init{
        itemView.setOnClickListener(this)
    }
    val name : TextView = view.findViewById(R.id.name)
    val desc : TextView = view.findViewById(R.id.desc)
    override fun onClick(p0: View?) {
        val position = adapterPosition
        onCardClick(position)
    }

}